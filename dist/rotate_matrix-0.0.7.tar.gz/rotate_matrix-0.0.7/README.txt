ROTATE MATRIX:

Rotate any matrix of any type, either clockwise or anti-clockwise instantly. 

Contains two functions:

1) clockwise: Takes l as parameter which is of type list, and pases the clockwised rotated version list l.

2) anti-clockwise: Takes l as parameter which is of type list, and passes the anti-clockwise rotated version of list l.
